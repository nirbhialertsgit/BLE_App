// Ensure getRandomValues exists on RN
import 'react-native-get-random-values';

// Use explicit .js subpaths so Metro resolves ESM correctly
import { hkdf } from '@noble/hashes/hkdf.js';
import { sha256 } from '@noble/hashes/sha256.js';
import { utf8ToBytes } from '@noble/hashes/utils.js';

/**
 * Derive a session key with HKDF-SHA256.
 * ikm/salt/info are byte arrays; len defaults to 32 bytes.
 */
export function deriveSessionKey(
  ikm: Uint8Array,
  salt?: Uint8Array,
  info?: Uint8Array,
  len: number = 32
): Uint8Array {
  return hkdf(sha256, ikm, salt, info, len);
}

/**
 * Convenience: derive from strings (UTF-8) without TextEncoder.
 */
export function deriveSessionKeyFromString(
  ikm: string,
  salt?: string,
  info?: string,
  len: number = 32
): Uint8Array {
  return deriveSessionKey(
    utf8ToBytes(ikm),
    salt ? utf8ToBytes(salt) : undefined,
    info ? utf8ToBytes(info) : undefined,
    len
  );
}
