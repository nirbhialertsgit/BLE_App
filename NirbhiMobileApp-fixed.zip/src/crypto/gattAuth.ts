import { hmac } from '@noble/hashes/hmac.js';
import { sha256 } from '@noble/hashes/sha256.js';
import { hexToBytes, bytesToHex } from './sessionKey';

/**
 * Computes HMAC-SHA256 authentication tag for GATT operations
 * tag = HMAC-SHA256(sessionKey, nonce || mmid)
 */
export function computeAuthTag(
  sessionKey: Uint8Array,
  nonce: Uint8Array,
  mmid: string
): Uint8Array {
  // Convert MMID hex to bytes
  const mmidBytes = hexToBytes(mmid);
  
  // Concatenate nonce and MMID
  const message = new Uint8Array(nonce.length + mmidBytes.length);
  message.set(nonce, 0);
  message.set(mmidBytes, nonce.length);
  
  // Compute HMAC-SHA256
  return hmac(sha256, sessionKey, message);
}

/**
 * Validates authentication tag
 */
export function validateAuthTag(
  sessionKey: Uint8Array,
  nonce: Uint8Array,
  mmid: string,
  receivedTag: Uint8Array
): boolean {
  const computedTag = computeAuthTag(sessionKey, nonce, mmid);
  
  // Constant-time comparison
  if (computedTag.length !== receivedTag.length) {
    return false;
  }
  
  let result = 0;
  for (let i = 0; i < computedTag.length; i++) {
    result |= computedTag[i] ^ receivedTag[i];
  }
  
  return result === 0;
}