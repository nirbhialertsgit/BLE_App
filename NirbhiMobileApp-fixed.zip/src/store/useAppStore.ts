import { create } from 'zustand';
import { AppState, TripSession, ProximityState } from '../types';

interface AppStore extends AppState {
  // Session actions
  setSession: (session: TripSession) => void;
  clearSession: () => void;
  
  // Monitoring actions
  startMonitoring: () => void;
  stopMonitoring: () => void;
  setScanning: (scanning: boolean) => void;
  
  // Device actions
  setDeviceFound: (found: boolean) => void;
  updateProximity: (proximity: ProximityState) => void;
  
  // Alert actions
  startAlert: () => void;
  stopAlert: () => void;
  
  // GATT actions
  setGattAuthenticated: (authenticated: boolean) => void;
  setConnectedDevice: (device: any) => void;
  
  // Settings actions
  toggleMockMode: () => void;
  setPermissionsGranted: (granted: boolean) => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  // Initial state
  session: null,
  isMonitoring: false,
  isScanning: false,
  deviceFound: false,
  proximity: {
    level: 'Lost',
    rssi: -100,
    smoothedRssi: -100,
    lastSeen: 0,
    isDebouncing: false,
  },
  isAlerting: false,
  isGattAuthenticated: false,
  connectedDevice: null,
  mockMode: false,
  permissionsGranted: false,
  
  // Session actions
  setSession: (session) => set({ session }),
  clearSession: () => set({ 
    session: null, 
    isMonitoring: false,
    isScanning: false,
    deviceFound: false,
    isAlerting: false,
    isGattAuthenticated: false,
    connectedDevice: null,
  }),
  
  // Monitoring actions
  startMonitoring: () => set({ isMonitoring: true }),
  stopMonitoring: () => set({ 
    isMonitoring: false, 
    isScanning: false, 
    deviceFound: false, 
    isAlerting: false 
  }),
  setScanning: (scanning) => set({ isScanning: scanning }),
  
  // Device actions
  setDeviceFound: (found) => set({ deviceFound: found }),
  updateProximity: (proximity) => set({ proximity }),
  
  // Alert actions
  startAlert: () => set({ isAlerting: true }),
  stopAlert: () => set({ isAlerting: false }),
  
  // GATT actions
  setGattAuthenticated: (authenticated) => set({ isGattAuthenticated: authenticated }),
  setConnectedDevice: (device) => set({ connectedDevice: device }),
  
  // Settings actions
  toggleMockMode: () => set((state) => ({ mockMode: !state.mockMode })),
  setPermissionsGranted: (granted) => set({ permissionsGranted: granted }),
}));