import { BleManager, Device } from 'react-native-ble-plx';
import { BLE_CONFIG } from '../constants/ble';
import { DeviceData } from '../types';
import { bytesToHex } from '../crypto/sessionKey';

export class BLEScanner {
  private bleManager: BleManager;
  private scanTimer: NodeJS.Timeout | null = null;
  private sleepTimer: NodeJS.Timeout | null = null;
  private isScanning: boolean = false;
  
  constructor(
    private targetMmid: string,
    private onDeviceFound: (data: DeviceData) => void,
    private onScanStatusChange: (scanning: boolean) => void
  ) {
    this.bleManager = BleManager ? new BleManager() : null;
  }
  
  async startDutyCycleScanning(): Promise<void> {
    if (this.isScanning) {
      return;
    }
    
    console.log('Starting duty cycle BLE scanning...');
    this.scheduleScanCycle();
  }
  
  stopScanning(): void {
    console.log('Stopping BLE scanning...');
    
    if (this.scanTimer) {
      clearTimeout(this.scanTimer);
      this.scanTimer = null;
    }
    
    if (this.sleepTimer) {
      clearTimeout(this.sleepTimer);
      this.sleepTimer = null;
    }
    
    this.bleManager.stopDeviceScan();
    this.isScanning = false;
    this.onScanStatusChange(false);
  }
  
  private scheduleScanCycle(): void {
    // Start scanning phase
    this.startScanPhase();
    
    // Schedule sleep phase
    this.scanTimer = setTimeout(() => {
      this.stopScanPhase();
      this.startSleepPhase();
    }, BLE_CONFIG.SCAN_CONFIG.SCAN_DURATION);
  }
  
  private startScanPhase(): void {
    this.isScanning = true;
    this.onScanStatusChange(true);
    
    console.log(`Scanning for ${BLE_CONFIG.SCAN_CONFIG.SCAN_DURATION}ms...`);
    
    this.bleManager.startDeviceScan(
      [BLE_CONFIG.SERVICE_UUID],
      {
        allowDuplicates: BLE_CONFIG.SCAN_CONFIG.ALLOW_DUPLICATES,
      },
      (error, device) => {
        if (error) {
          console.error('BLE scan error:', error);
          return;
        }
        
        if (device) {
          this.handleDevice(device);
        }
      }
    );
  }
  
  private stopScanPhase(): void {
    this.bleManager.stopDeviceScan();
  }
  
  private startSleepPhase(): void {
    this.isScanning = false;
    this.onScanStatusChange(false);
    
    console.log(`Sleeping for ${BLE_CONFIG.SCAN_CONFIG.SLEEP_DURATION}ms...`);
    
    this.sleepTimer = setTimeout(() => {
      this.scheduleScanCycle();
    }, BLE_CONFIG.SCAN_CONFIG.SLEEP_DURATION);
  }
  
  private handleDevice(device: Device): void {
    const serviceData = device.serviceData?.[BLE_CONFIG.SERVICE_UUID];
    
    if (!serviceData) {
      return;
    }
    
    // Parse service data: [MMID(6) | TX_POWER(1) | ROLLING_NONCE(2)]
    const data = this.parseServiceData(serviceData);
    
    if (!data) {
      return;
    }
    
    // Filter by target MMID
    if (data.mmid !== this.targetMmid.toUpperCase()) {
      return;
    }
    
    // Update with current RSSI and timestamp
    const deviceData: DeviceData = {
      ...data,
      rssi: device.rssi || -100,
      timestamp: Date.now(),
    };
    
    console.log('SmartBox found:', deviceData);
    this.onDeviceFound(deviceData);
  }
  
  private parseServiceData(serviceData: string): Omit<DeviceData, 'rssi' | 'timestamp'> | null {
    try {
      // Service data is base64 encoded
      const bytes = new Uint8Array(
        atob(serviceData)
          .split('')
          .map(char => char.charCodeAt(0))
      );
      
      if (bytes.length !== BLE_CONFIG.SERVICE_DATA_LAYOUT.TOTAL_LENGTH) {
        console.warn('Invalid service data length:', bytes.length);
        return null;
      }
      
      // Extract MMID (6 bytes)
      const mmidBytes = bytes.slice(0, 6);
      const mmid = bytesToHex(mmidBytes);
      
      // Extract TX Power (1 byte, signed)
      const txPowerByte = bytes[6];
      const txPower = txPowerByte > 127 ? txPowerByte - 256 : txPowerByte;
      
      // Extract Rolling Nonce (2 bytes)
      const nonceBytes = bytes.slice(7, 9);
      const rollingNonce = (nonceBytes[0] << 8) | nonceBytes[1];
      
      return {
        mmid,
        txPower,
        rollingNonce,
      };
    } catch (error) {
      console.error('Error parsing service data:', error);
      return null;
    }
  }
  
  async checkBluetoothState(): Promise<boolean> {
    try {
      const state = await this.bleManager.state();
      return state === 'PoweredOn';
    } catch (error) {
      console.error('Error checking Bluetooth state:', error);
      return false;
    }
  }
  
  destroy(): void {
    this.stopScanning();
    this.bleManager.destroy();
  }
}