import { BleManager, Device, Characteristic } from 'react-native-ble-plx';
import { BLE_CONFIG, BUZZER_COMMANDS } from '../constants/ble';
import { computeAuthTag, validateAuthTag } from '../crypto/gattAuth';
import { bytesToHex, hexToBytes } from '../crypto/sessionKey';

/**
 * Handles optional GATT authentication and buzzer control
 * Note: This is for authenticated operations only, no bonding/pairing required
 */
export class GATTAuthenticator {
  private bleManager: BleManager;
  
  constructor() {
    this.bleManager = BleManager ? new BleManager() : null;
  }
  
  /**
   * Connects to device and performs authentication
   */
  async authenticateDevice(device: Device, sessionKey: Uint8Array, mmid: string): Promise<boolean> {
    try {
      console.log('Connecting to device for GATT authentication...');
      
      // Connect without bonding
      const connectedDevice = await device.connect();
      
      // Discover services and characteristics
      await connectedDevice.discoverAllServicesAndCharacteristics();
      
      // Read nonce from device
      const nonce = await this.readNonce(connectedDevice);
      if (!nonce) {
        await connectedDevice.cancelConnection();
        return false;
      }
      
      // Compute authentication tag
      const authTag = computeAuthTag(sessionKey, nonce, mmid);
      
      // Write auth tag to device
      const authSuccess = await this.writeAuthTag(connectedDevice, authTag);
      
      if (!authSuccess) {
        await connectedDevice.cancelConnection();
        return false;
      }
      
      console.log('GATT authentication successful');
      return true;
      
    } catch (error) {
      console.error('GATT authentication failed:', error);
      return false;
    }
  }
  
  /**
   * Reads nonce from NONCE characteristic
   */
  private async readNonce(device: Device): Promise<Uint8Array | null> {
    try {
      const characteristic = await device.readCharacteristicForService(
        BLE_CONFIG.SERVICE_UUID,
        BLE_CONFIG.CHARACTERISTICS.NONCE
      );
      
      if (!characteristic.value) {
        console.error('No nonce value received');
        return null;
      }
      
      // Decode base64 nonce
      const nonceBytes = new Uint8Array(
        atob(characteristic.value)
          .split('')
          .map(char => char.charCodeAt(0))
      );
      
      console.log('Nonce received:', bytesToHex(nonceBytes));
      return nonceBytes;
      
    } catch (error) {
      console.error('Failed to read nonce:', error);
      return null;
    }
  }
  
  /**
   * Writes authentication tag to AUTH characteristic
   */
  private async writeAuthTag(device: Device, authTag: Uint8Array): Promise<boolean> {
    try {
      // Encode auth tag as base64
      const base64AuthTag = btoa(String.fromCharCode(...authTag));
      
      await device.writeCharacteristicWithResponseForService(
        BLE_CONFIG.SERVICE_UUID,
        BLE_CONFIG.CHARACTERISTICS.AUTH,
        base64AuthTag
      );
      
      console.log('Auth tag written successfully');
      return true;
      
    } catch (error) {
      console.error('Failed to write auth tag:', error);
      return false;
    }
  }
  
  /**
   * Controls buzzer (requires prior authentication)
   */
  async controlBuzzer(device: Device, turnOn: boolean): Promise<boolean> {
    try {
      const command = turnOn ? BUZZER_COMMANDS.BUZZ_ON : BUZZER_COMMANDS.BUZZ_OFF;
      const base64Command = btoa(String.fromCharCode(...command));
      
      await device.writeCharacteristicWithResponseForService(
        BLE_CONFIG.SERVICE_UUID,
        BLE_CONFIG.CHARACTERISTICS.BUZZER_CONTROL,
        base64Command
      );
      
      console.log(`Buzzer ${turnOn ? 'ON' : 'OFF'} command sent`);
      return true;
      
    } catch (error) {
      console.error('Failed to control buzzer:', error);
      return false;
    }
  }
}