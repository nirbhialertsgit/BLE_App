import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

export class HapticService {
  private alertInterval: NodeJS.Timeout | null = null;
  
  /**
   * Start proximity lost alert haptics
   * 3 long pulses, repeat every 5s
   */
  startLostAlert(): void {
    if (Platform.OS !== 'android') {
      console.log('Haptic feedback is Android-only in this implementation');
      return;
    }
    
    this.stopLostAlert(); // Clear any existing alerts
    
    console.log('Starting haptic lost alert...');
    this.triggerLostHaptics();
    
    // Repeat every 5 seconds
    this.alertInterval = setInterval(() => {
      this.triggerLostHaptics();
    }, 5000);
  }
  
  /**
   * Stop proximity lost alert haptics
   */
  stopLostAlert(): void {
    if (this.alertInterval) {
      clearInterval(this.alertInterval);
      this.alertInterval = null;
      console.log('Haptic lost alert stopped');
    }
  }
  
  /**
   * Trigger single haptic feedback for found state
   */
  async triggerFoundFeedback(): Promise<void> {
    if (Platform.OS !== 'android') {
      return;
    }
    
    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch (error) {
      console.error('Haptic feedback error:', error);
    }
  }
  
  /**
   * Trigger 3 long pulses for lost alert
   */
  private async triggerLostHaptics(): Promise<void> {
    try {
      // 3 long pulses with gaps
      for (let i = 0; i < 3; i++) {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
        
        if (i < 2) {
          // Wait between pulses
          await new Promise(resolve => setTimeout(resolve, 200));
        }
      }
    } catch (error) {
      console.error('Haptic feedback error:', error);
    }
  }
}