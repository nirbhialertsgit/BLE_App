import { Platform } from 'react-native';
import notifee, { AndroidImportance, AndroidVisibility } from '@notifee/react-native';

/**
 * Manages foreground service for background BLE monitoring
 * Note: This requires proper Android configuration for production builds
 */
export class ForegroundService {
  private static channelId = 'smartbox-monitoring';
  private static notificationId = 'monitoring-service';
  
  static async initialize(): Promise<void> {
    if (Platform.OS !== 'android') {
      return;
    }
    
    try {
      // Create notification channel for foreground service
      await notifee.createChannel({
        id: this.channelId,
        name: 'SmartBox Monitoring',
        description: 'Ongoing proximity monitoring notifications',
        importance: AndroidImportance.LOW,
        visibility: AndroidVisibility.PUBLIC,
      });
    } catch (error) {
      console.error('Failed to initialize notification channel:', error);
    }
  }
  
  static async startForegroundService(): Promise<void> {
    if (Platform.OS !== 'android') {
      console.log('Foreground service is Android-only');
      return;
    }
    
    try {
      await notifee.displayNotification({
        id: this.notificationId,
        title: 'SmartBoxLeash Active',
        body: 'Monitoring proximity to your SmartBox device',
        android: {
          channelId: this.channelId,
          importance: AndroidImportance.LOW,
          visibility: AndroidVisibility.PUBLIC,
          ongoing: true,
          asForegroundService: true,
          actions: [
            {
              title: 'Stop Monitoring',
              pressAction: {
                id: 'stop-monitoring',
              },
            },
          ],
        },
      });
      
      console.log('Foreground service started');
    } catch (error) {
      console.error('Failed to start foreground service:', error);
    }
  }
  
  static async stopForegroundService(): Promise<void> {
    if (Platform.OS !== 'android') {
      return;
    }
    
    try {
      await notifee.cancelNotification(this.notificationId);
      console.log('Foreground service stopped');
    } catch (error) {
      console.error('Failed to stop foreground service:', error);
    }
  }
  
  static async updateServiceNotification(status: string, proximity?: string): Promise<void> {
    if (Platform.OS !== 'android') {
      return;
    }
    
    try {
      await notifee.displayNotification({
        id: this.notificationId,
        title: 'SmartBoxLeash Active',
        body: `${status}${proximity ? ` • ${proximity}` : ''}`,
        android: {
          channelId: this.channelId,
          importance: AndroidImportance.LOW,
          visibility: AndroidVisibility.PUBLIC,
          ongoing: true,
          asForegroundService: true,
          actions: [
            {
              title: 'Stop Monitoring',
              pressAction: {
                id: 'stop-monitoring',
              },
            },
          ],
        },
      });
    } catch (error) {
      console.error('Failed to update service notification:', error);
    }
  }
}