import { BLEScanner } from '../ble/Scanner';
import { ProximityMonitor } from '../logic/Proximity';
import { HapticService } from './HapticService';
import { ForegroundService } from './ForegroundService';
import { MockRssiSimulator } from '../mock/MockRssi';
import { useAppStore } from '../store/useAppStore';
import { DeviceData } from '../types';

export class MonitoringService {
  private scanner: BLEScanner | null = null;
  private proximityMonitor: ProximityMonitor | null = null;
  private hapticService = new HapticService();
  private mockSimulator: MockRssiSimulator | null = null;
  private timeoutCheckInterval: NodeJS.Timeout | null = null;
  
  async startMonitoring(targetMmid: string, mockMode: boolean = false): Promise<void> {
    console.log('Starting proximity monitoring...', { targetMmid, mockMode });
    
    // Initialize proximity monitor
    this.proximityMonitor = new ProximityMonitor(
      (result) => {
        // Update store with proximity data
        useAppStore.getState().updateProximity({
          level: result.level,
          rssi: result.rssi,
          smoothedRssi: result.smoothedRssi,
          lastSeen: Date.now(),
          isDebouncing: result.isDebouncing,
        });
        
        // Update foreground service notification
        ForegroundService.updateServiceNotification(
          result.isDebouncing ? 'Checking connection...' : 'Monitoring active',
          `${result.level} (${Math.round(result.smoothedRssi)} dBm)`
        );
      },
      () => {
        // Lost alert
        console.log('Device lost - triggering alert');
        useAppStore.getState().startAlert();
        this.hapticService.startLostAlert();
      },
      () => {
        // Found alert
        console.log('Device found - stopping alert');
        useAppStore.getState().stopAlert();
        this.hapticService.stopLostAlert();
        this.hapticService.triggerFoundFeedback();
      }
    );
    
    if (mockMode) {
      // Start mock simulation
      this.startMockMode();
    } else {
      // Start real BLE scanning
      this.scanner = new BLEScanner(
        targetMmid,
        (deviceData) => this.handleDeviceData(deviceData),
        (scanning) => useAppStore.getState().setScanning(scanning)
      );
      
      await this.scanner.startDutyCycleScanning();
    }
    
    // Start timeout checking
    this.startTimeoutChecking();
    
    // Start foreground service
    await ForegroundService.startForegroundService();
    
    useAppStore.getState().startMonitoring();
  }
  
  async stopMonitoring(): Promise<void> {
    console.log('Stopping proximity monitoring...');
    
    // Stop scanning
    if (this.scanner) {
      this.scanner.stopScanning();
      this.scanner = null;
    }
    
    // Stop mock mode
    if (this.mockSimulator) {
      this.mockSimulator.stop();
      this.mockSimulator = null;
    }
    
    // Stop timeout checking
    if (this.timeoutCheckInterval) {
      clearInterval(this.timeoutCheckInterval);
      this.timeoutCheckInterval = null;
    }
    
    // Stop alerts
    this.hapticService.stopLostAlert();
    
    // Stop foreground service
    await ForegroundService.stopForegroundService();
    
    // Reset proximity monitor
    if (this.proximityMonitor) {
      this.proximityMonitor.reset();
    }
    
    useAppStore.getState().stopMonitoring();
  }
  
  private handleDeviceData(deviceData: DeviceData): void {
    console.log('Device data received:', deviceData);
    
    useAppStore.getState().setDeviceFound(true);
    
    if (this.proximityMonitor) {
      this.proximityMonitor.updateRssi(deviceData.rssi);
    }
  }
  
  private startMockMode(): void {
    console.log('Starting mock RSSI mode...');
    
    this.mockSimulator = new MockRssiSimulator((rssi) => {
      // Simulate device data
      const deviceData: DeviceData = {
        mmid: useAppStore.getState().session?.mmidHex || '',
        txPower: -10,
        rollingNonce: Math.floor(Math.random() * 65535),
        rssi,
        timestamp: Date.now(),
      };
      
      this.handleDeviceData(deviceData);
    });
    
    this.mockSimulator.start();
    useAppStore.getState().setScanning(true);
  }
  
  private startTimeoutChecking(): void {
    this.timeoutCheckInterval = setInterval(() => {
      if (this.proximityMonitor) {
        this.proximityMonitor.checkTimeout();
      }
    }, 1000); // Check every second
  }
  
  setMockScenario(scenario: 'stable_near' | 'stable_far' | 'gradual_loss' | 'random'): void {
    if (this.mockSimulator) {
      this.mockSimulator.setScenario(scenario);
    }
  }
}

// Singleton instance
export const monitoringService = new MonitoringService();