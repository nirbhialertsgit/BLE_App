import { Platform, PermissionsAndroid } from 'react-native';

export class PermissionService {
  /**
   * Request all required Android 12+ BLE permissions
   */
  static async requestBlePermissions(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      console.log('Permission checks are Android-only');
      return true;
    }
    
    try {
      const permissions = [
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS,
      ];
      
      console.log('Requesting BLE permissions...');
      
      const results = await PermissionsAndroid.requestMultiple(permissions);
      
      const allGranted = permissions.every(
        permission => results[permission] === PermissionsAndroid.RESULTS.GRANTED
      );
      
      console.log('BLE permissions result:', allGranted);
      return allGranted;
      
    } catch (error) {
      console.error('Permission request failed:', error);
      return false;
    }
  }
  
  /**
   * Check if all required permissions are granted
   */
  static async checkBlePermissions(): Promise<boolean> {
    if (Platform.OS !== 'android') {
      return true;
    }
    
    try {
      const permissions = [
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      ];
      
      const results = await Promise.all(
        permissions.map(permission => 
          PermissionsAndroid.check(permission)
        )
      );
      
      return results.every(result => result === true);
      
    } catch (error) {
      console.error('Permission check failed:', error);
      return false;
    }
  }
}