import AsyncStorage from '@react-native-async-storage/async-storage';
import { TripSession } from '../types';

const STORAGE_KEYS = {
  TRIP_SESSION: 'trip_session',
  MONITORING_STATE: 'monitoring_state',
} as const;

export class StorageService {
  /**
   * Save trip session to AsyncStorage
   */
  static async saveSession(session: TripSession): Promise<void> {
    try {
      // Convert Uint8Array sessionKey to hex for storage
      const sessionToStore = {
        ...session,
        sessionKey: Array.from(session.sessionKey),
      };
      
      await AsyncStorage.setItem(
        STORAGE_KEYS.TRIP_SESSION,
        JSON.stringify(sessionToStore)
      );
      
      console.log('Session saved to AsyncStorage');
    } catch (error) {
      console.error('Failed to save session:', error);
      throw error;
    }
  }
  
  /**
   * Load trip session from AsyncStorage
   */
  static async loadSession(): Promise<TripSession | null> {
    try {
      const sessionData = await AsyncStorage.getItem(STORAGE_KEYS.TRIP_SESSION);
      
      if (!sessionData) {
        return null;
      }
      
      const parsed = JSON.parse(sessionData);
      
      // Convert sessionKey array back to Uint8Array
      const session: TripSession = {
        ...parsed,
        sessionKey: new Uint8Array(parsed.sessionKey),
      };
      
      console.log('Session loaded from AsyncStorage');
      return session;
      
    } catch (error) {
      console.error('Failed to load session:', error);
      return null;
    }
  }
  
  /**
   * Clear trip session
   */
  static async clearSession(): Promise<void> {
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.TRIP_SESSION);
      console.log('Session cleared from AsyncStorage');
    } catch (error) {
      console.error('Failed to clear session:', error);
    }
  }
  
  /**
   * Save monitoring state
   */
  static async saveMonitoringState(isMonitoring: boolean): Promise<void> {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.MONITORING_STATE,
        JSON.stringify({ isMonitoring, savedAt: Date.now() })
      );
    } catch (error) {
      console.error('Failed to save monitoring state:', error);
    }
  }
  
  /**
   * Load monitoring state
   */
  static async loadMonitoringState(): Promise<boolean> {
    try {
      const stateData = await AsyncStorage.getItem(STORAGE_KEYS.MONITORING_STATE);
      
      if (!stateData) {
        return false;
      }
      
      const { isMonitoring } = JSON.parse(stateData);
      return isMonitoring || false;
      
    } catch (error) {
      console.error('Failed to load monitoring state:', error);
      return false;
    }
  }
}