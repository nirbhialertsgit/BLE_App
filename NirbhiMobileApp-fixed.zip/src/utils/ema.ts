import { BLE_CONFIG } from '../constants/ble';

/**
 * Exponential Moving Average for RSSI smoothing
 */
export class EMAFilter {
  private value: number = -100;
  private initialized: boolean = false;
  
  constructor(private alpha: number = BLE_CONFIG.EMA_ALPHA) {}
  
  update(newValue: number): number {
    if (!this.initialized) {
      this.value = newValue;
      this.initialized = true;
    } else {
      this.value = this.alpha * newValue + (1 - this.alpha) * this.value;
    }
    
    return this.value;
  }
  
  getValue(): number {
    return this.value;
  }
  
  reset(): void {
    this.initialized = false;
    this.value = -100;
  }
}