import { BLE_CONFIG } from '../constants/ble';
import { EMAFilter } from '../utils/ema';
import type { ProximityLevel } from '../constants/ble';

export interface ProximityResult {
  level: ProximityLevel;
  rssi: number;
  smoothedRssi: number;
  isDebouncing: boolean;
}

export class ProximityMonitor {
  private emaFilter = new EMAFilter();
  private lastSeen: number = 0;
  private debounceTimer: NodeJS.Timeout | null = null;
  private currentLevel: ProximityLevel = 'Lost';
  private isDebouncing: boolean = false;
  
  private onProximityChange?: (result: ProximityResult) => void;
  private onLostAlert?: () => void;
  private onFoundAlert?: () => void;
  
  constructor(
    onProximityChange?: (result: ProximityResult) => void,
    onLostAlert?: () => void,
    onFoundAlert?: () => void
  ) {
    this.onProximityChange = onProximityChange;
    this.onLostAlert = onLostAlert;
    this.onFoundAlert = onFoundAlert;
  }
  
  updateRssi(rssi: number): ProximityResult {
    const now = Date.now();
    this.lastSeen = now;
    
    // Apply EMA smoothing
    const smoothedRssi = this.emaFilter.update(rssi);
    
    // Determine proximity level from smoothed RSSI
    let newLevel: ProximityLevel;
    if (smoothedRssi >= BLE_CONFIG.PROXIMITY_THRESHOLDS.NEAR) {
      newLevel = 'Near';
    } else if (smoothedRssi >= BLE_CONFIG.PROXIMITY_THRESHOLDS.MEDIUM) {
      newLevel = 'Medium';
    } else {
      newLevel = 'Far';
    }
    
    this.handleLevelChange(newLevel);
    
    const result: ProximityResult = {
      level: this.currentLevel,
      rssi,
      smoothedRssi,
      isDebouncing: this.isDebouncing,
    };
    
    this.onProximityChange?.(result);
    return result;
  }
  
  checkTimeout(): void {
    const now = Date.now();
    const timeSinceLastSeen = now - this.lastSeen;
    
    // If no frames for >= 10s, consider as timeout
    if (timeSinceLastSeen >= BLE_CONFIG.TIMEOUTS.LOST_TIMEOUT) {
      this.handleLevelChange('Lost');
    }
  }
  
  private handleLevelChange(newLevel: ProximityLevel): void {
    const prevLevel = this.currentLevel;
    
    // Handle debouncing logic
    if (newLevel === 'Far' || newLevel === 'Lost') {
      if (prevLevel === 'Near' || prevLevel === 'Medium') {
        // Start debounce timer for Lost state
        this.startLostDebounce();
      }
    } else if (newLevel === 'Near' || newLevel === 'Medium') {
      if (prevLevel === 'Far' || prevLevel === 'Lost' || this.isDebouncing) {
        // Clear lost state and debouncing
        this.clearLostDebounce();
        this.currentLevel = newLevel;
        
        if (prevLevel === 'Lost') {
          this.onFoundAlert?.();
        }
      } else {
        this.currentLevel = newLevel;
      }
    }
  }
  
  private startLostDebounce(): void {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    
    this.isDebouncing = true;
    
    this.debounceTimer = setTimeout(() => {
      this.currentLevel = 'Lost';
      this.isDebouncing = false;
      this.onLostAlert?.();
    }, BLE_CONFIG.TIMEOUTS.LOST_DEBOUNCE);
  }
  
  private clearLostDebounce(): void {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    this.isDebouncing = false;
  }
  
  reset(): void {
    this.emaFilter.reset();
    this.lastSeen = 0;
    this.currentLevel = 'Lost';
    this.clearLostDebounce();
  }
  
  getCurrentLevel(): ProximityLevel {
    return this.currentLevel;
  }
}