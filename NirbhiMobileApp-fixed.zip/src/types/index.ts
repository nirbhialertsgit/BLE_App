export interface TripSession {
  tripId: string;
  mmidHex: string;
  sessionKey: Uint8Array;
  startedAt: number;
}

export interface DeviceData {
  mmid: string;
  txPower: number;
  rollingNonce: number;
  rssi: number;
  timestamp: number;
}

export interface ProximityState {
  level: 'Near' | 'Medium' | 'Far' | 'Lost';
  rssi: number;
  smoothedRssi: number;
  lastSeen: number;
  isDebouncing: boolean;
}

export interface AppState {
  // Trip session
  session: TripSession | null;
  
  // Monitoring state
  isMonitoring: boolean;
  isScanning: boolean;
  
  // Device state
  deviceFound: boolean;
  proximity: ProximityState;
  
  // Alert state
  isAlerting: boolean;
  
  // GATT authentication
  isGattAuthenticated: boolean;
  connectedDevice: any | null;
  
  // Mock mode
  mockMode: boolean;
  
  // Permissions
  permissionsGranted: boolean;
}