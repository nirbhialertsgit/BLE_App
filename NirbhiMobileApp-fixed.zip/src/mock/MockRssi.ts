import { BLE_CONFIG } from '../constants/ble';

export class MockRssiSimulator {
  private interval: NodeJS.Timeout | null = null;
  private currentRssi: number = -50;
  private direction: number = -1;
  private phase: 'near' | 'moving_away' | 'far' | 'moving_closer' = 'near';
  
  constructor(private onRssiUpdate: (rssi: number) => void) {}
  
  start(): void {
    if (this.interval) {
      return;
    }
    
    console.log('Starting mock RSSI simulation...');
    
    this.interval = setInterval(() => {
      this.updateRssi();
      this.onRssiUpdate(this.currentRssi);
    }, 1000); // Update every second
  }
  
  stop(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    console.log('Mock RSSI simulation stopped');
  }
  
  private updateRssi(): void {
    // Simulate realistic RSSI fluctuations
    const noise = (Math.random() - 0.5) * 10; // ±5 dB noise
    
    switch (this.phase) {
      case 'near':
        this.currentRssi = -45 + noise;
        if (Math.random() < 0.1) { // 10% chance to start moving away
          this.phase = 'moving_away';
          this.direction = -1;
        }
        break;
        
      case 'moving_away':
        this.currentRssi += this.direction * (2 + Math.random() * 3) + noise;
        if (this.currentRssi <= -85) {
          this.phase = 'far';
        }
        break;
        
      case 'far':
        this.currentRssi = -85 + noise;
        if (Math.random() < 0.15) { // 15% chance to start coming back
          this.phase = 'moving_closer';
          this.direction = 1;
        }
        break;
        
      case 'moving_closer':
        this.currentRssi += this.direction * (1.5 + Math.random() * 2) + noise;
        if (this.currentRssi >= -50) {
          this.phase = 'near';
        }
        break;
    }
    
    // Keep within reasonable bounds
    this.currentRssi = Math.max(-100, Math.min(-30, this.currentRssi));
  }
  
  getCurrentRssi(): number {
    return this.currentRssi;
  }
  
  setScenario(scenario: 'stable_near' | 'stable_far' | 'gradual_loss' | 'random'): void {
    switch (scenario) {
      case 'stable_near':
        this.currentRssi = -45;
        this.phase = 'near';
        break;
      case 'stable_far':
        this.currentRssi = -85;
        this.phase = 'far';
        break;
      case 'gradual_loss':
        this.currentRssi = -45;
        this.phase = 'moving_away';
        break;
      case 'random':
        this.phase = 'near';
        break;
    }
  }
}