# Change Log (auto-generated)

- package.json: pin @noble/hashes to 1.4.0
- metro.config.js: add resolver.unstable_enablePackageExports = true
- 1 file(s): use explicit @noble/hashes subpath .js imports
- 2 file(s): guard BLE import & instantiation for Expo Go

## Files changed (by sha1)

- metro.config.js : (new) -> fd0361aaf2d0
- package.json : 318e4ef485c8 -> 8f0d9fea866f
- src/ble/Auth.ts : 8c7bf6e4db9d -> 66699e503845
- src/ble/Scanner.ts : 4c601130dfc5 -> 5d9a002a00cf
- src/crypto/gattAuth.ts : 849772735d7f -> a831c1851b5a