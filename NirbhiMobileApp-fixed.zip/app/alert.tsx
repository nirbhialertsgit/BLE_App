import React, { useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { TriangleAlert as AlertTriangle, CircleStop as StopCircle } from 'lucide-react-native';
import { useAppStore } from '../src/store/useAppStore';
import { monitoringService } from '../src/services/MonitoringService';

export default function AlertScreen() {
  const { proximity, stopAlert } = useAppStore();
  
  useEffect(() => {
    // Auto-dismiss alert if device is found again
    if (proximity.level === 'Near' || proximity.level === 'Medium') {
      handleStopAlert();
    }
  }, [proximity.level]);
  
  const handleStopAlert = async () => {
    stopAlert();
    await monitoringService.stopMonitoring();
    router.back();
  };
  
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#DC2626" barStyle="light-content" />
      
      <View style={styles.alertContent}>
        <AlertTriangle size={120} color="#FFFFFF" />
        
        <Text style={styles.alertTitle}>SMARTBOX LOST</Text>
        <Text style={styles.alertSubtitle}>
          Connection lost to your SmartBox device
        </Text>
        
        <View style={styles.alertInfo}>
          <Text style={styles.alertInfoText}>
            Last seen: {Math.floor((Date.now() - proximity.lastSeen) / 1000)}s ago
          </Text>
          <Text style={styles.alertInfoText}>
            Signal: {Math.round(proximity.smoothedRssi)} dBm
          </Text>
        </View>
        
        <TouchableOpacity
          style={styles.stopButton}
          onPress={handleStopAlert}
        >
          <StopCircle size={24} color="#FFFFFF" />
          <Text style={styles.stopButtonText}>Stop Alert</Text>
        </TouchableOpacity>
        
        <Text style={styles.helpText}>
          Move closer to your SmartBox or tap Stop Alert to end monitoring
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#DC2626',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  alertContent: {
    alignItems: 'center',
    width: '100%',
  },
  alertTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 24,
    marginBottom: 8,
    textAlign: 'center',
  },
  alertSubtitle: {
    fontSize: 18,
    color: '#FEE2E2',
    marginBottom: 32,
    textAlign: 'center',
  },
  alertInfo: {
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 32,
    width: '100%',
    alignItems: 'center',
  },
  alertInfoText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginBottom: 4,
  },
  stopButton: {
    backgroundColor: '#7F1D1D',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  stopButtonText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  helpText: {
    color: '#FEE2E2',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});