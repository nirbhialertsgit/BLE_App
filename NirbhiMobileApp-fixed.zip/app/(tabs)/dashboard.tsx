import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { 
  Play, 
  Square, 
  Wifi, 
  WifiOff, 
  Zap,
  Clock,
  Signal
} from 'lucide-react-native';
import { useAppStore } from '../../src/store/useAppStore';
import { monitoringService } from '../../src/services/MonitoringService';
import { PermissionService } from '../../src/services/PermissionService';
import { ForegroundService } from '../../src/services/ForegroundService';
import { StorageService } from '../../src/services/StorageService';

export default function DashboardScreen() {
  const {
    session,
    isMonitoring,
    isScanning,
    deviceFound,
    proximity,
    isAlerting,
    isGattAuthenticated,
    mockMode,
    permissionsGranted,
    clearSession,
    toggleMockMode,
    setPermissionsGranted,
  } = useAppStore();
  
  const [lastSeenText, setLastSeenText] = useState('Never');
  
  useEffect(() => {
    initializeServices();
    checkPermissions();
  }, []);
  
  useEffect(() => {
    // Update last seen text
    if (proximity.lastSeen > 0) {
      const updateLastSeen = () => {
        const elapsed = Date.now() - proximity.lastSeen;
        const seconds = Math.floor(elapsed / 1000);
        
        if (seconds < 60) {
          setLastSeenText(`${seconds}s ago`);
        } else {
          const minutes = Math.floor(seconds / 60);
          setLastSeenText(`${minutes}m ago`);
        }
      };
      
      updateLastSeen();
      const interval = setInterval(updateLastSeen, 1000);
      
      return () => clearInterval(interval);
    } else {
      setLastSeenText('Never');
    }
  }, [proximity.lastSeen]);
  
  const initializeServices = async () => {
    await ForegroundService.initialize();
  };
  
  const checkPermissions = async () => {
    const granted = await PermissionService.checkBlePermissions();
    setPermissionsGranted(granted);
  };
  
  const requestPermissions = async () => {
    const granted = await PermissionService.requestBlePermissions();
    setPermissionsGranted(granted);
    
    if (!granted) {
      Alert.alert(
        'Permissions Required',
        'Bluetooth and location permissions are required for proximity monitoring.',
        [{ text: 'OK' }]
      );
    }
  };
  
  const handleStartMonitoring = async () => {
    if (!session) {
      Alert.alert('Error', 'No active trip session');
      return;
    }
    
    if (!permissionsGranted) {
      await requestPermissions();
      return;
    }
    
    try {
      await monitoringService.startMonitoring(session.mmidHex, mockMode);
    } catch (error) {
      console.error('Failed to start monitoring:', error);
      Alert.alert('Error', 'Failed to start monitoring');
    }
  };
  
  const handleStopMonitoring = async () => {
    try {
      await monitoringService.stopMonitoring();
    } catch (error) {
      console.error('Failed to stop monitoring:', error);
    }
  };
  
  const handleEndTrip = () => {
    Alert.alert(
      'End Trip',
      'Are you sure you want to end the current trip? This will clear the session.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Trip',
          style: 'destructive',
          onPress: async () => {
            await handleStopMonitoring();
            await StorageService.clearSession();
            clearSession();
            router.replace('/');
          },
        },
      ]
    );
  };
  
  const getProximityColor = (level: string): string => {
    switch (level) {
      case 'Near': return '#10B981';
      case 'Medium': return '#F59E0B';
      case 'Far': return '#EF4444';
      case 'Lost': return '#DC2626';
      default: return '#6B7280';
    }
  };
  
  const getStatusText = (): string => {
    if (!isMonitoring) return 'Monitoring Stopped';
    if (isAlerting) return 'DEVICE LOST - ALERT ACTIVE';
    if (!deviceFound) return 'Searching for SmartBox...';
    if (proximity.isDebouncing) return 'Checking connection...';
    return `SmartBox ${proximity.level}`;
  };
  
  if (!session) {
    return (
      <View style={styles.container}>
        <Text style={styles.noSessionText}>No active trip session</Text>
        <TouchableOpacity 
          style={styles.button}
          onPress={() => router.replace('/')}
        >
          <Text style={styles.buttonText}>Start New Trip</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContainer}>
      {/* Status Header */}
      <View style={styles.statusHeader}>
        <Text style={[styles.statusText, { color: getProximityColor(proximity.level) }]}>
          {getStatusText()}
        </Text>
        {isScanning && <Wifi size={20} color="#3B82F6" />}
        {!isScanning && isMonitoring && <WifiOff size={20} color="#6B7280" />}
      </View>
      
      {/* Trip Info */}
      <View style={styles.tripInfo}>
        <Text style={styles.sectionTitle}>Trip Information</Text>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Trip ID:</Text>
          <Text style={styles.infoValue}>{session.tripId}</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>MMID:</Text>
          <Text style={styles.infoValue}>{session.mmidHex}</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Started:</Text>
          <Text style={styles.infoValue}>
            {new Date(session.startedAt).toLocaleString()}
          </Text>
        </View>
      </View>
      
      {/* Proximity Status */}
      <View style={styles.proximitySection}>
        <Text style={styles.sectionTitle}>Proximity Status</Text>
        
        <View style={styles.proximityBar}>
          <View style={[
            styles.proximityLevel,
            { backgroundColor: proximity.level === 'Near' ? '#10B981' : '#374151' }
          ]}>
            <Text style={styles.proximityLabel}>Near</Text>
          </View>
          <View style={[
            styles.proximityLevel,
            { backgroundColor: proximity.level === 'Medium' ? '#F59E0B' : '#374151' }
          ]}>
            <Text style={styles.proximityLabel}>Medium</Text>
          </View>
          <View style={[
            styles.proximityLevel,
            { backgroundColor: proximity.level === 'Far' ? '#EF4444' : '#374151' }
          ]}>
            <Text style={styles.proximityLabel}>Far</Text>
          </View>
          <View style={[
            styles.proximityLevel,
            { backgroundColor: proximity.level === 'Lost' ? '#DC2626' : '#374151' }
          ]}>
            <Text style={styles.proximityLabel}>Lost</Text>
          </View>
        </View>
        
        <View style={styles.signalInfo}>
          <View style={styles.signalRow}>
            <Signal size={16} color="#9CA3AF" />
            <Text style={styles.signalText}>
              RSSI: {Math.round(proximity.smoothedRssi)} dBm
            </Text>
          </View>
          <View style={styles.signalRow}>
            <Clock size={16} color="#9CA3AF" />
            <Text style={styles.signalText}>Last seen: {lastSeenText}</Text>
          </View>
        </View>
      </View>
      
      {/* Controls */}
      <View style={styles.controls}>
        {!isMonitoring ? (
          <TouchableOpacity
            style={styles.startButton}
            onPress={handleStartMonitoring}
            disabled={!permissionsGranted}
          >
            <Play size={20} color="#FFFFFF" />
            <Text style={styles.startButtonText}>Start Monitoring</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={styles.stopButton}
            onPress={handleStopMonitoring}
          >
            <Square size={20} color="#FFFFFF" />
            <Text style={styles.stopButtonText}>Stop Monitoring</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity
          style={[styles.buzzerButton, !isGattAuthenticated && styles.buzzerButtonDisabled]}
          disabled={!isGattAuthenticated}
        >
          <Zap size={20} color={isGattAuthenticated ? "#FFFFFF" : "#6B7280"} />
          <Text style={[
            styles.buzzerButtonText,
            !isGattAuthenticated && styles.buzzerButtonTextDisabled
          ]}>
            Buzz Box
          </Text>
        </TouchableOpacity>
      </View>
      
      {/* Settings */}
      <View style={styles.settings}>
        <TouchableOpacity
          style={[styles.mockButton, mockMode && styles.mockButtonActive]}
          onPress={toggleMockMode}
        >
          <Text style={styles.mockButtonText}>
            Mock Mode: {mockMode ? 'ON' : 'OFF'}
          </Text>
        </TouchableOpacity>
        
        {!permissionsGranted && (
          <TouchableOpacity
            style={styles.permissionButton}
            onPress={requestPermissions}
          >
            <Text style={styles.permissionButtonText}>Grant Permissions</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity
          style={styles.endTripButton}
          onPress={handleEndTrip}
        >
          <Text style={styles.endTripButtonText}>End Trip</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 24,
  },
  noSessionText: {
    color: '#9CA3AF',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
  },
  statusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 32,
    padding: 20,
    backgroundColor: '#1F2937',
    borderRadius: 16,
  },
  statusText: {
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
  },
  tripInfo: {
    backgroundColor: '#1F2937',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  infoLabel: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  infoValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  proximitySection: {
    backgroundColor: '#1F2937',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  proximityBar: {
    flexDirection: 'row',
    marginBottom: 16,
    borderRadius: 8,
    overflow: 'hidden',
  },
  proximityLevel: {
    flex: 1,
    padding: 12,
    alignItems: 'center',
  },
  proximityLabel: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  signalInfo: {
    gap: 8,
  },
  signalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  signalText: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  controls: {
    gap: 12,
    marginBottom: 24,
  },
  startButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  startButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  stopButton: {
    backgroundColor: '#EF4444',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  stopButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  buzzerButton: {
    backgroundColor: '#8B5CF6',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  buzzerButtonDisabled: {
    backgroundColor: '#374151',
  },
  buzzerButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  buzzerButtonTextDisabled: {
    color: '#6B7280',
  },
  settings: {
    gap: 12,
  },
  mockButton: {
    backgroundColor: '#374151',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  mockButtonActive: {
    backgroundColor: '#3B82F6',
  },
  mockButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  permissionButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  permissionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  endTripButton: {
    backgroundColor: '#DC2626',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  endTripButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  button: {
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    margin: 24,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});