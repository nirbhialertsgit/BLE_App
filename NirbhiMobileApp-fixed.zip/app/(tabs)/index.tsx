import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { Shield } from 'lucide-react-native';
import { deriveSessionKey } from '../../src/crypto/sessionKey';
import { StorageService } from '../../src/services/StorageService';
import { useAppStore } from '../../src/store/useAppStore';

export default function TripStartScreen() {
  const [otp, setOtp] = useState('');
  const [mmid, setMmid] = useState('');
  const [tripId, setTripId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { session, setSession } = useAppStore();
  
  // Load existing session on mount
  useEffect(() => {
    loadExistingSession();
  }, []);
  
  const loadExistingSession = async () => {
    try {
      const savedSession = await StorageService.loadSession();
      if (savedSession) {
        setSession(savedSession);
        // If session exists, navigate to dashboard
        router.replace('/dashboard');
      }
    } catch (error) {
      console.error('Failed to load session:', error);
    }
  };
  
  const validateInputs = (): boolean => {
    if (!otp.trim()) {
      Alert.alert('Error', 'OTP is required');
      return false;
    }
    
    if (!mmid.trim()) {
      Alert.alert('Error', 'MMID is required');
      return false;
    }
    
    // Validate MMID format (12 hex characters)
    const mmidRegex = /^[0-9A-Fa-f]{12}$/;
    if (!mmidRegex.test(mmid)) {
      Alert.alert('Error', 'MMID must be 12 hexadecimal characters');
      return false;
    }
    
    if (!tripId.trim()) {
      Alert.alert('Error', 'Trip ID is required');
      return false;
    }
    
    return true;
  };
  
  const handleSubmit = async () => {
    if (!validateInputs()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Derive session key using HKDF-SHA256
      const sessionKey = deriveSessionKey(otp, mmid, tripId);
      
      // Create trip session
      const newSession = {
        tripId: tripId.trim(),
        mmidHex: mmid.trim().toUpperCase(),
        sessionKey,
        startedAt: Date.now(),
      };
      
      // Save to AsyncStorage
      await StorageService.saveSession(newSession);
      
      // Update store
      setSession(newSession);
      
      console.log('Trip session created:', {
        tripId: newSession.tripId,
        mmidHex: newSession.mmidHex,
        startedAt: newSession.startedAt,
      });
      
      // Navigate to dashboard
      router.replace('/dashboard');
      
    } catch (error) {
      console.error('Failed to create session:', error);
      Alert.alert('Error', 'Failed to create trip session. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Shield size={64} color="#3B82F6" />
          <Text style={styles.title}>SmartBoxLeash</Text>
          <Text style={styles.subtitle}>Enter trip authorization details</Text>
        </View>
        
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>OTP</Text>
            <TextInput
              style={styles.input}
              value={otp}
              onChangeText={setOtp}
              placeholder="Enter one-time password"
              placeholderTextColor="#9CA3AF"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>MMID (12 hex characters)</Text>
            <TextInput
              style={styles.input}
              value={mmid}
              onChangeText={(text) => setMmid(text.replace(/[^0-9A-Fa-f]/g, '').toUpperCase())}
              placeholder="A1B2C3D4E5F6"
              placeholderTextColor="#9CA3AF"
              maxLength={12}
              autoCapitalize="characters"
              autoCorrect={false}
            />
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Trip ID</Text>
            <TextInput
              style={styles.input}
              value={tripId}
              onChangeText={setTripId}
              placeholder="Enter trip identifier"
              placeholderTextColor="#9CA3AF"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
          
          <TouchableOpacity
            style={[styles.submitButton, isSubmitting && styles.submitButtonDisabled]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            <Text style={styles.submitButtonText}>
              {isSubmitting ? 'Authorizing...' : 'Authorize Trip'}
            </Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.info}>
          <Text style={styles.infoText}>
            Session key will be derived using HKDF-SHA256 for secure proximity monitoring
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 48,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 16,
  },
  subtitle: {
    fontSize: 16,
    color: '#9CA3AF',
    marginTop: 8,
    textAlign: 'center',
  },
  form: {
    marginBottom: 32,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1F2937',
    borderWidth: 1,
    borderColor: '#374151',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
  },
  submitButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  submitButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  info: {
    padding: 16,
    backgroundColor: '#1F2937',
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6',
  },
  infoText: {
    color: '#9CA3AF',
    fontSize: 14,
    lineHeight: 20,
  },
});