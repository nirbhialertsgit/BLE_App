import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Settings as SettingsIcon, TestTube, Trash2 } from 'lucide-react-native';
import { useAppStore } from '../../src/store/useAppStore';
import { monitoringService } from '../../src/services/MonitoringService';
import { StorageService } from '../../src/services/StorageService';

export default function SettingsScreen() {
  const { mockMode, toggleMockMode, session } = useAppStore();
  
  const handleMockScenario = (scenario: 'stable_near' | 'stable_far' | 'gradual_loss' | 'random') => {
    if (!mockMode) {
      Alert.alert('Mock Mode Required', 'Enable mock mode to test scenarios');
      return;
    }
    
    monitoringService.setMockScenario(scenario);
    Alert.alert('Scenario Set', `Mock scenario changed to: ${scenario.replace('_', ' ')}`);
  };
  
  const handleClearData = () => {
    Alert.alert(
      'Clear All Data',
      'This will clear all stored trip data. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            await StorageService.clearSession();
            Alert.alert('Data Cleared', 'All data has been cleared');
          },
        },
      ]
    );
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContainer}>
      <View style={styles.header}>
        <SettingsIcon size={40} color="#3B82F6" />
        <Text style={styles.title}>Settings</Text>
      </View>
      
      {/* Mock Mode Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Mock Mode</Text>
        <Text style={styles.sectionDescription}>
          Test proximity detection without real hardware
        </Text>
        
        <TouchableOpacity
          style={[styles.toggleButton, mockMode && styles.toggleButtonActive]}
          onPress={toggleMockMode}
        >
          <Text style={styles.toggleButtonText}>
            Mock Mode: {mockMode ? 'ON' : 'OFF'}
          </Text>
        </TouchableOpacity>
        
        {mockMode && (
          <View style={styles.mockScenarios}>
            <Text style={styles.subsectionTitle}>Test Scenarios</Text>
            
            <TouchableOpacity
              style={styles.scenarioButton}
              onPress={() => handleMockScenario('stable_near')}
            >
              <Text style={styles.scenarioButtonText}>Stable Near</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.scenarioButton}
              onPress={() => handleMockScenario('stable_far')}
            >
              <Text style={styles.scenarioButtonText}>Stable Far</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.scenarioButton}
              onPress={() => handleMockScenario('gradual_loss')}
            >
              <Text style={styles.scenarioButtonText}>Gradual Loss</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.scenarioButton}
              onPress={() => handleMockScenario('random')}
            >
              <Text style={styles.scenarioButtonText}>Random Walk</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      
      {/* BLE Configuration Info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>BLE Configuration</Text>
        <View style={styles.configInfo}>
          <Text style={styles.configLabel}>Service UUID:</Text>
          <Text style={styles.configValue}>0000ABCD-0000-1000-8000-00805F9B34FB</Text>
        </View>
        <View style={styles.configInfo}>
          <Text style={styles.configLabel}>Scan Cycle:</Text>
          <Text style={styles.configValue}>5s scan / 10s sleep</Text>
        </View>
        <View style={styles.configInfo}>
          <Text style={styles.configLabel}>EMA Alpha:</Text>
          <Text style={styles.configValue}>0.2</Text>
        </View>
      </View>
      
      {/* Data Management */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Data Management</Text>
        
        <TouchableOpacity
          style={styles.clearButton}
          onPress={handleClearData}
        >
          <Trash2 size={16} color="#FFFFFF" />
          <Text style={styles.clearButtonText}>Clear All Data</Text>
        </TouchableOpacity>
      </View>
      
      {/* App Info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>App Information</Text>
        <Text style={styles.infoText}>
          SmartBoxLeash v1.0.0{'\n'}
          BLE proximity monitoring without pairing{'\n'}
          OTP-gated secure authentication
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollContainer: {
    padding: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 12,
  },
  section: {
    backgroundColor: '#1F2937',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  sectionDescription: {
    color: '#9CA3AF',
    fontSize: 14,
    marginBottom: 16,
  },
  subsectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  toggleButton: {
    backgroundColor: '#374151',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  toggleButtonActive: {
    backgroundColor: '#3B82F6',
  },
  toggleButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  mockScenarios: {
    marginTop: 16,
    gap: 8,
  },
  scenarioButton: {
    backgroundColor: '#374151',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  scenarioButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
  },
  configInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  configLabel: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  configValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  clearButton: {
    backgroundColor: '#DC2626',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  clearButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  infoText: {
    color: '#9CA3AF',
    fontSize: 14,
    lineHeight: 20,
  },
});