// polyfills must load first
import 'react-native-get-random-values';
import 'react-native-url-polyfill/auto';

import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Platform } from 'react-native';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { useAppStore } from '../src/store/useAppStore';
import { StorageService } from '../src/services/StorageService';

export default function RootLayout() {
  useFrameworkReady(); // keep as is

  const { isAlerting, setSession } = useAppStore();

  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    // Load existing session
    try {
      const session = await StorageService.loadSession();
      if (session) {
        setSession(session);
      }
    } catch (error) {
      console.error('Failed to load session on startup:', error);
    }
  };

  // Show alert screen when alerting
  useEffect(() => {
    if (isAlerting) {
      // Navigate to alert screen
      import('expo-router').then(({ router }) => {
        router.push('/alert');
      });
    }
  }, [isAlerting]);

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen
          name="alert"
          options={{
            presentation: 'fullScreenModal',
            gestureEnabled: false,
          }}
        />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="light" />
    </>
  );
}
